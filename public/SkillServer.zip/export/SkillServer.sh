#!/bin/sh
cd /home/pi/skillserver
java -server -jar SkillServer.jar @launchparams.cfg