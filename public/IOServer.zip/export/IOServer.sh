#!/bin/sh
cd /home/pi/ioserver
java -server -jar IOServer.jar @launchparams.cfg