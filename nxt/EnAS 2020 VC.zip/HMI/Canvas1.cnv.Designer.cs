﻿/*
 * Created by nxtSTUDIO.
 * User: prana
 * Date: 4/24/2020
 * Time: 7:48 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas1.
	/// </summary>
	partial class Canvas1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      		this.Name = "Canvas1";
			this.Size = new System.Drawing.Size(800,720);
			this.Brush = new NxtControl.Drawing.Brush("CanvasBrush");
            
            
		}
		#endregion
	}
}
