﻿/*
 * Created by nxtSTUDIO.
 * User: prana
 * Date: 4/24/2020
 * Time: 7:48 PM
 * 
 */
using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

using NxtControl.GuiFramework;

namespace HMI.Main.Canvases
{
	/// <summary>
	/// Summary description for Canvas1.
	/// </summary>
	partial class Canvas1
	{
		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.HMI = new HMI.Main.Symbols.ProductOrder.sDefault();
			// 
			// HMI
			// 
			this.HMI.BeginInit();
			this.HMI.AngleIgnore = false;
			this.HMI.DesignTransformation = new NxtControl.Drawing.Matrix(0.91738594327990131D, 0D, 0D, 0.97492163009404387D, 5D, 18D);
			this.HMI.Name = "HMI";
			this.HMI.SecurityToken = ((uint)(4294967295u));
			this.HMI.TagName = "D3E8C9274E6153B0";
			this.HMI.EndInit();
			// 
			// Canvas1
			// 
			this.Bounds = new NxtControl.Drawing.RectF(((float)(0D)), ((float)(0D)), ((float)(800D)), ((float)(720D)));
			this.Brush = new NxtControl.Drawing.Brush("CanvasBrush");
			this.Name = "Canvas1";
			this.Shapes.AddRange(new System.ComponentModel.IComponent[] {
									this.HMI});
			this.Size = new System.Drawing.Size(800, 720);
		}
		private HMI.Main.Symbols.ProductOrder.sDefault HMI;
		#endregion
	}
}
